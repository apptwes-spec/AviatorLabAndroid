package com.aviatorlab.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.*
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AviatorLabApp() }
    }
}

@Composable
fun AviatorLabApp() {
    var entry by remember { mutableStateOf("") }
    var rounds by remember { mutableStateOf(listOf<Double>()) }
    val avg = if (rounds.isEmpty()) 0.0 else rounds.average()
    val high = rounds.count { it >= 2.0 }
    val low = rounds.count { it < 2.0 }
    val infinite = rememberInfiniteTransition(label = "plane")
    val offset by infinite.animateFloat(
        initialValue = -12f, targetValue = 12f,
        animationSpec = infiniteRepeatable(tween(1700, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "float"
    )

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFFFF3B45), background = Color(0xFF101116),
        surface = Color(0xFF1B1D25), secondary = Color(0xFFFFC857)
    )) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF101116)) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
                Text("AVIATOR LAB", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
                Text("متابعة وتحليل سجل الجولات", color = Color.LightGray, fontSize = 14.sp)
                Spacer(Modifier.height(18.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF20232D)),
                    shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("✈", fontSize = 54.sp, modifier = Modifier.offset(x = offset.dp))
                        Text("AVIATOR", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Text("سجّل النتائج بنفسك لمراجعة سجلّك", color = Color.LightGray, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    StatCard("عدد الجولات", rounds.size.toString(), Modifier.weight(1f))
                    StatCard("المتوسط", if (rounds.isEmpty()) "—" else "%.2fx".format(avg), Modifier.weight(1f))
                    StatCard("أعلى نتيجة", if (rounds.isEmpty()) "—" else "%.2fx".format(rounds.maxOrNull()), Modifier.weight(1f))
                }
                Spacer(Modifier.height(18.dp))
                Text("إضافة نتيجة", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = entry, onValueChange = { entry = it },
                        modifier = Modifier.weight(1f), singleLine = true,
                        label = { Text("مثال: 1.75") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFFF3B45), unfocusedBorderColor = Color.Gray,
                            focusedLabelColor = Color(0xFFFF3B45), unfocusedLabelColor = Color.LightGray
                        )
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = {
                        val value = entry.trim().replace(',', '.').toDoubleOrNull()
                        if (value != null && value >= 1.0 && value <= 100000.0) {
                            rounds = listOf(value) + rounds
                            entry = ""
                        }
                    }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF3B45))) {
                        Text("إضافة", color = Color.White)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF20232D)),
                    shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("ملخص السجل", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("نتائج 2.00x أو أكثر: $high", color = Color(0xFF70D6A5))
                        Text("نتائج أقل من 2.00x: $low", color = Color(0xFFFF9B9B))
                        Text(
                            if (rounds.isEmpty()) "أضف نتائج لعرض إحصاء وصفي."
                            else "النسبة المسجلة فوق 2x: ${((high.toDouble()/rounds.size)*100).roundToInt()}%",
                            color = Color.LightGray
                        )
                        Spacer(Modifier.height(6.dp))
                        Text("الإحصاءات تصف النتائج السابقة فقط ولا تتنبأ بالجولة القادمة أو تضمن الربح.",
                            color = Color(0xFFFFC857), fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("آخر النتائج", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    TextButton(onClick = { rounds = emptyList() }) { Text("مسح السجل", color = Color(0xFFFF9B9B)) }
                }
                if (rounds.isEmpty()) Text("مفيش نتائج مضافة لسه", color = Color.Gray)
                else rounds.take(50).forEachIndexed { index, value ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)
                        .background(Color(0xFF20232D), RoundedCornerShape(12.dp)).padding(13.dp),
                        horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("#${rounds.size - index}", color = Color.LightGray)
                        Text("%.2fx".format(value), color = if (value >= 2) Color(0xFF70D6A5) else Color(0xFFFF9B9B),
                            fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(20.dp))
                Text("Aviator Lab • أداة تسجيل ومراجعة فقط", color = Color.Gray, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color(0xFF20232D)),
        shape = RoundedCornerShape(15.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(title, color = Color.LightGray, fontSize = 11.sp)
            Spacer(Modifier.height(5.dp))
            Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        }
    }
}
